package com.intellilearn.delivery.controller;


import com.intellilearn.dto.PaymentDTO;
import com.intellilearn.onlinestore.model.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * @author Yuqing Luo
 * @date 2024/10/25 11:09
 */
@RestController
@RequestMapping("/store")
public class OrderController {

    @Qualifier("httpOutChannel")
    @Autowired
    private MessageChannel httpOutChannel;

    @Autowired
    @Qualifier("httpReplyChannel")
    private MessageChannel httpReplyChannel;

    private ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

    @PostMapping("/placedOrder")
    public Result handlePayment(@RequestBody PaymentDTO paymentDTO) {
        System.out.println("Received payment info: " + paymentDTO);
        scheduler.schedule(() -> {
            Message<PaymentDTO> message = MessageBuilder.withPayload(paymentDTO)
                    .setReplyChannel(httpReplyChannel)
                    .build();
            httpOutChannel.send(message);
        }, 15, TimeUnit.SECONDS);
        System.out.println("Received payment info: " + paymentDTO);
        return Result.success(paymentDTO);
    }
}