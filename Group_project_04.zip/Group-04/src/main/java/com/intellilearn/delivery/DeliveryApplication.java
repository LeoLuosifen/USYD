package com.intellilearn.delivery;

import com.intellilearn.delivery.service.DeliveryService;
import com.intellilearn.dto.PaymentDTO;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.support.MessageBuilder;

import java.time.LocalDateTime;

/**
 * @author Yuqing Luo
 * @date 2024/10/24 21:37
 */
@EnableIntegration
@PropertySource(value = "classpath:application-delivery.properties")
@SpringBootApplication(scanBasePackages = "com.intellilearn.delivery")
public class DeliveryApplication {
    public static void main(String[] args) {
        SpringApplication.run(DeliveryApplication.class, args);
    }
}
