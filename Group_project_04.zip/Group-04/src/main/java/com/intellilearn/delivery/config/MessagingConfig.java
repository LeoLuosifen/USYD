package com.intellilearn.delivery.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.channel.PublishSubscribeChannel;
import org.springframework.integration.http.outbound.HttpRequestExecutingMessageHandler;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;

/**
 * @author Yuqing Luo
 * @date 2024/10/25 11:07
 */
@Configuration
public class MessagingConfig {
    @Bean
    public MessageChannel jdbcMessageChannel() {
        return new PublishSubscribeChannel();
    }

    @Bean
    public MessageChannel httpOutChannel() {
        return new DirectChannel();
    }

    @Bean
    public MessageChannel httpReplyChannel() {
        return new DirectChannel();
    }

    @Bean
    @ServiceActivator(inputChannel = "httpReplyChannel")
    public MessageHandler replyHandler() {
        return message -> {
            System.out.println("Received reply: " + message.getPayload());
        };
    }

    @Bean
    @ServiceActivator(inputChannel = "httpOutChannel")
    public HttpRequestExecutingMessageHandler httpRequestHandler() {
        HttpRequestExecutingMessageHandler handler = new HttpRequestExecutingMessageHandler("http://localhost:8083/email");
        handler.setHttpMethod(HttpMethod.POST);
        handler.setExpectedResponseType(String.class);
        return handler;
    }
}
