package com.intellilearn.delivery.service;

import com.intellilearn.dto.PaymentDTO;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

/**
 * @author Yuqing Luo
 * @date 2024/10/24 22:45
 */
@Service
public class DeliveryService {

    public DeliveryService() {
        System.out.println("DeliveryService initialized");
    }

    @ServiceActivator(inputChannel = "jdbcMessageChannel")
    public void handlePaymentInfo(Message<PaymentDTO> message){
        try {
            PaymentDTO paymentDTO = message.getPayload();
            System.out.println("Received payment info: " + paymentDTO);
        } catch (Exception e) {
            System.err.println("Error handling message: " + e.getMessage());
            e.printStackTrace();
        }
    }


}
