package com.intellilearn.emailProvider.service;

import com.intellilearn.dto.EmailDTO;
import com.intellilearn.dto.PaymentDTO;
import com.intellilearn.emailProvider.model.Customer;
import com.intellilearn.emailProvider.model.EmailMessage;
import com.intellilearn.emailProvider.model.OrderStatus;
import com.intellilearn.emailProvider.model.Orders;
import com.intellilearn.emailProvider.repository.CustomerRepository;
import com.intellilearn.emailProvider.repository.EmailMessageRepository;
import com.intellilearn.emailProvider.repository.OrderRepository;
import com.intellilearn.emailProvider.repository.OrderStatusRepository;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * @author Yuqing Luo
 * @date 2024/10/25 13:12
 */
@Service
@Slf4j
public class EmailService {

    @Qualifier("httpOutChannel")
    @Autowired
    private MessageChannel httpOutChannel;

    @Autowired
    @Qualifier("httpReplyChannel")
    private MessageChannel httpReplyChannel;

    @Autowired
    private EmailMessageRepository emailMessageRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private OrderStatusRepository orderStatusRepository;

    private Random random = new Random();

    @Transactional
    public void processOrder(PaymentDTO paymentDTO){
        // Get order and customer info
        Integer orderId = paymentDTO.getOrderId();
        Orders orders = orderRepository.findById(orderId).orElseThrow(() -> new RuntimeException("Order not found"));

        Integer customerId = orders.getCustomer().getId();
        Customer customer = customerRepository.findById(customerId).orElseThrow(() -> new RuntimeException("Customer not found"));

        if (orders.getOrderStatus().equals(orderStatusRepository.findById(4).orElseThrow(() -> new RuntimeException("Unknown state")))){
            System.out.println("The order has been cancelled, so dont need to deliver");
            sendEmail(customer, orders, "Customer cancelled the order");
//            throw new IllegalStateException("Order has been cancelled.");
            return;
        }

        // Set initial status to shipped
        OrderStatus shippedState = orderStatusRepository.findById(2).orElseThrow(() -> new RuntimeException("Unknown state"));
        orders.setOrderStatus(shippedState);
        orderRepository.save(orders);
        log.info("orders: {}", orders);
        sendEmail(customer, orders, "Your order has been shipped!");

        // Timed tasks, shipped and delivered in 10 seconds or less
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

        scheduler.schedule(() -> {
            if (random.nextDouble() < 0.05){
                OrderStatus lostStatus = orderStatusRepository.findById(5).orElseThrow(() -> new RuntimeException("Unknown state"));
                orders.setOrderStatus(lostStatus);
                log.info("orders: {}", orders);
                orderRepository.save(orders);
                sendEmail(customer, orders, "Your order has been lost. We apologize for the inconvenience.");
            }else {
                OrderStatus deliveredStatus = orderStatusRepository.findById(3).orElseThrow(() -> new RuntimeException("Unknown state"));
                orders.setOrderStatus(deliveredStatus);
                log.info("orders: {}", orders);
                orderRepository.save(orders);
                sendEmail(customer, orders, "Your order has been delivered!");
            }
        }, 10, TimeUnit.SECONDS);
    }

    public void sendEmail(Customer customer, Orders orders, String message){
        EmailMessage emailMessage = new EmailMessage();
        emailMessage.setCustomer(customer);
        emailMessage.setMessage(message);
        emailMessage.setReceivedTime(LocalDateTime.now());

        log.info("emailMessage: {}", emailMessage);
        emailMessageRepository.save(emailMessage);
        EmailDTO emailDTO = new EmailDTO();
        emailDTO.setOrderId(orders.getId());
        emailDTO.setCustomerId(customer.getId());
        emailDTO.setMessage(message);

        Message<EmailDTO> sendMessage = MessageBuilder.withPayload(emailDTO)
                .setReplyChannel(httpReplyChannel)
                .build();
        httpOutChannel.send(sendMessage);
        System.out.println("Sent email to customer: " + customer.getEmail() + " with message: " + message);
    }
}
