package com.intellilearn.emailProvider.controller;

import com.intellilearn.dto.PaymentDTO;
import com.intellilearn.emailProvider.service.EmailService;
import com.intellilearn.onlinestore.model.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Yuqing Luo
 * @date 2024/10/25 13:17
 */
@RestController
@RequestMapping("/email")
public class EmailController {

    @Autowired
    private EmailService emailService;

    @PostMapping
    public Result sendEmailToCustomer(@RequestBody PaymentDTO paymentDTO){

        System.out.println("Received payment, start to delivery");
        emailService.processOrder(paymentDTO);
        return Result.success();
    }
}
