package com.intellilearn.emailProvider.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.intellilearn.emailProvider.model.Customer;
import com.intellilearn.emailProvider.model.Product;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;


@Entity
@Data
public class Orders {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     *
     */
    @ManyToOne
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    /**
     *
     */
    @OneToOne
    @JoinColumn(name = "order_status", nullable = false)
    private OrderStatus orderStatus;

    /**
     *
     */
    @Column(nullable = false)
    private double totalPrice;

    /**
     *
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdTime;

    /**
     *
     */
    @OneToOne
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;

    /**
     *
     */
    @Column(nullable = false)
    private Integer quantity;

    @Column(nullable = false)
    private String address;
}
