package com.intellilearn.emailProvider.repository;

import com.intellilearn.emailProvider.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {

    Customer findByUsername(String username);
}
