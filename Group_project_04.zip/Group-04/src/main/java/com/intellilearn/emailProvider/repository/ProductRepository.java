package com.intellilearn.emailProvider.repository;

import com.intellilearn.emailProvider.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Yuqing Luo
 * @date 2024/10/22 14:36
 */
public interface ProductRepository extends JpaRepository<Product, Integer> {
}
