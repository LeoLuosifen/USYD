package com.intellilearn.emailProvider.repository;

import com.intellilearn.emailProvider.model.OrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Yuqing Luo
 * @date 2024/10/24 13:33
 */
public interface OrderStatusRepository extends JpaRepository<OrderStatus, Integer> {
}
