package com.intellilearn.emailProvider;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;
import org.springframework.integration.config.EnableIntegration;

/**
 * @author Yuqing Luo
 * @date 2024/10/25 12:45
 */
@EnableIntegration
@PropertySource(value = "classpath:application-email.properties")
@SpringBootApplication(scanBasePackages = "com.intellilearn.emailProvider")
public class EmailProviderApplication {
    public static void main(String[] args) {
        SpringApplication.run(EmailProviderApplication.class, args);
    }
}
