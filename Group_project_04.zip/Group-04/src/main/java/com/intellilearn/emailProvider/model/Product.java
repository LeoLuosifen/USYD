package com.intellilearn.emailProvider.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     *
     */
    @Column(nullable = false)
    private String productName;

    /**
     *
     */
    private String productDescription;

    /**
     *
     */
    @Column(nullable = false)
    private double price;
}
