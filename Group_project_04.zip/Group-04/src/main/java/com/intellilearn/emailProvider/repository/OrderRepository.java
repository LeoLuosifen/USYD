package com.intellilearn.emailProvider.repository;

import com.intellilearn.emailProvider.model.Orders;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepository extends JpaRepository<Orders, Integer> {
}
