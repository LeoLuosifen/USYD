package com.intellilearn.emailProvider.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.intellilearn.emailProvider.model.Customer;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author Yuqing Luo
 * @date 2024/10/25 12:59
 */
@Data
@Entity
public class EmailMessage {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @ManyToOne
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;
    private String message;
    @JsonFormat(pattern = "yyyy:MM:dd HH:mm:ss")
    private LocalDateTime receivedTime;
}
