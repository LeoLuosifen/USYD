package com.intellilearn.onlinestore.repository;

import com.intellilearn.onlinestore.model.WarehouseStock;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface WarehouseStockRepository extends JpaRepository<WarehouseStock, Integer> {

    List<WarehouseStock> findWarehouseStockById(Integer id);
}
