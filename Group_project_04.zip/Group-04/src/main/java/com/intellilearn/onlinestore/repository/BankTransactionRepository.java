package com.intellilearn.onlinestore.repository;

import com.intellilearn.onlinestore.model.BankTransaction;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Yuqing Luo
 * @date 2024/10/24 12:16
 */
public interface BankTransactionRepository extends JpaRepository<BankTransaction, Integer> {

    BankTransaction findBankTransactionByCustomerId(Integer customer_id);
}
