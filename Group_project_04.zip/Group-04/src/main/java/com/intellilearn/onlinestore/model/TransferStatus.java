package com.intellilearn.onlinestore.model;

import jakarta.persistence.*;
import lombok.Data;

/**
 * @author Yuqing Luo
 * @date 2024/10/24 12:12
 */
@Data
@Entity
public class TransferStatus {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(unique=true, nullable=false)
    private String name;
}