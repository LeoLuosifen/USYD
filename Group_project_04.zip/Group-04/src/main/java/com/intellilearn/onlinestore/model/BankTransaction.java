package com.intellilearn.onlinestore.model;

import jakarta.persistence.*;
import lombok.Data;

/**
 * @author Yuqing Luo
 * @date 2024/10/24 12:09
 */
@Data
@Entity
public class BankTransaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @OneToOne
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;
    private Double amount;
    private Integer status;
}
