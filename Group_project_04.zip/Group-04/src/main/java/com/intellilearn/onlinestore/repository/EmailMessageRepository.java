package com.intellilearn.onlinestore.repository;

import com.intellilearn.onlinestore.model.EmailMessage;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Yuqing Luo
 * @date 2024/10/25 13:06
 */
public interface EmailMessageRepository extends JpaRepository<EmailMessage, Integer> {
}
