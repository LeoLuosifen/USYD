package com.intellilearn.onlinestore.repository;

import com.intellilearn.onlinestore.model.TransferStatus;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Yuqing Luo
 * @date 2024/10/24 12:13
 */
public interface TransferStatusRepository extends JpaRepository<TransferStatus, Integer> {
}
