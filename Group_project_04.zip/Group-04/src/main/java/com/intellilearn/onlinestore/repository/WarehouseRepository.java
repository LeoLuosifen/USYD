package com.intellilearn.onlinestore.repository;

import com.intellilearn.onlinestore.model.Warehouse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WarehouseRepository extends JpaRepository<Warehouse, Integer> {
}
