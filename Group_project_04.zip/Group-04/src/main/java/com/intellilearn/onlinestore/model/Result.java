package com.intellilearn.onlinestore.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Yuqing Luo
 * @date 2024/10/22 14:37
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Result<T> {
    private Integer code;
    private String message;
    private T data;

    // 快速返回操作成功响应结果(带响应数据)
    public static <E> Result<E> success(E data) {
        return new Result<>(0, "Successfully!", data);
    }

    // 快速返回操作成功响应结果
    public static Result success() {
        return new Result<>(0, "Successfully!", null);
    }

    // 快速返回操作失败响应结果
    public static Result error(String message) {
        return new Result<>(1, message, null);
    }
}
