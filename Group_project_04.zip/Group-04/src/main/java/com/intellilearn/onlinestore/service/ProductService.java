package com.intellilearn.onlinestore.service;

import com.intellilearn.dto.PaymentDTO;
import com.intellilearn.dto.ProductDTO;
import com.intellilearn.onlinestore.model.*;
import com.intellilearn.onlinestore.repository.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jakarta.transaction.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Yuqing Luo
 * @date 2024/10/22 14:39
 */
@Service
@Slf4j
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private BankTransactionRepository bankTransactionRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private WarehouseStockService warehouseStockService;

    @Autowired
    private OrderStatusRepository orderStatusRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private TransferStatusRepository transferStatusRepository;

    public List<Product> getListOfProducts() {
        return productRepository.findAll();
    }

    @Transactional
    public PaymentDTO purchaseProduct(Integer customerId, ProductDTO request) {
        log.info("customerId: {}", customerId);
        Customer customer = null;
        if (customerId != null){
            customer = customerRepository.findById(customerId).orElseThrow();
        }

        Customer store = customerRepository.findByUsername("store");
        BankTransaction byCustomer = bankTransactionRepository.findBankTransactionByCustomerId(customer.getId());
        BankTransaction byStore = bankTransactionRepository.findBankTransactionByCustomerId(store.getId());
        Double price = request.getPrice();
        Integer quantity = request.getQuantity();

        warehouseStockService.getWarehousesToFulfillOrder(request.getId(), quantity);

        double totalPrice = price * quantity;
        log.info("totalPrice: {}", totalPrice);
        log.info("byCustomer.getAmount(): {}", byCustomer.getAmount());
        if (byCustomer.getAmount() < totalPrice){
            throw new IllegalArgumentException("Negative amount that cannot afford");
        }

        // Transfer
        byCustomer.setAmount(byCustomer.getAmount() - totalPrice);
        bankTransactionRepository.save(byCustomer);

        byStore.setAmount(byStore.getAmount() + totalPrice);
        bankTransactionRepository.save(byStore);

        Product product = null;

        if (request.getId() != null){
            product = productRepository.findById(request.getId()).orElseThrow();
        }

        OrderStatus orderStatus = orderStatusRepository.getReferenceById(1);

        Orders orders = new Orders();
        orders.setOrderStatus(orderStatus);
        orders.setCustomer(customer);
        orders.setProduct(product);
        orders.setTotalPrice(totalPrice);
        orders.setCreatedTime(LocalDateTime.now());
        orders.setQuantity(quantity);
        orders.setAddress(request.getAddress());

        orderRepository.save(orders);
        log.info("orderId: {}", orders.getId());

        TransferStatus transferStatus = transferStatusRepository.getReferenceById(1);
        Payment payment = new Payment();
        payment.setOrders(orders);
        payment.setStatus(transferStatus);
        payment.setAmount(totalPrice);
        payment.setPaymentDate(LocalDateTime.now());

        paymentRepository.save(payment);
        PaymentDTO paymentDTO = new PaymentDTO(payment.getId(), payment.getAmount(), 1, payment.getOrders().getId(), payment.getPaymentDate());
        return paymentDTO;
    }

    @Transactional
    public PaymentDTO cancelledOrder(Integer orderId) {
        Orders orders = orderRepository.findById(orderId).orElseThrow(() -> new RuntimeException("Order not found"));
        Product product = orders.getProduct();
        Integer quantity = orders.getQuantity();

        warehouseStockService.returnProducts(product.getId(), quantity);
        double totalPrice = orders.getTotalPrice();
        log.info("totalPrice: {}", totalPrice);
        Customer customer = orders.getCustomer();
        log.info("customer: {}", customer);

        Customer store = customerRepository.findByUsername("store");
        BankTransaction refundCustomer = bankTransactionRepository.findBankTransactionByCustomerId(customer.getId());
        BankTransaction byStore = bankTransactionRepository.findBankTransactionByCustomerId(store.getId());
        log.info("refundCustomer: {}", refundCustomer);
        log.info("byStore: {}", byStore);

        OrderStatus status = orders.getOrderStatus();
        Integer orderStatusId = status.getId();

        if (orderStatusId == 2){
            throw new IllegalArgumentException("The order has been shipped, you can not cancel.");
        }

        if (orderStatusId == 3){
            throw new IllegalArgumentException("The order has been delivered, you can not cancel.");
        }

        if (orderStatusId == 4){
            throw new IllegalArgumentException("The order has been cancelled, you can not cancel again.");
        }

        if (orderStatusId == 5){
            throw new IllegalArgumentException("The order has been lost, Sorry you can not cancel.");
        }

        // refund
        refundCustomer.setAmount(refundCustomer.getAmount() + totalPrice);
        bankTransactionRepository.save(refundCustomer);

        byStore.setAmount(byStore.getAmount() - totalPrice);
        bankTransactionRepository.save(byStore);
        log.info("refundCustomer: {}", refundCustomer);
        log.info("byStore: {}", byStore);

        Payment refundPayment = paymentRepository.findByOrdersId(orders.getId());

        OrderStatus orderStatus = orderStatusRepository.getReferenceById(4);
        orders.setOrderStatus(orderStatus);
        orderRepository.save(orders);
        TransferStatus cancelledStatus = transferStatusRepository.getReferenceById(2);
        refundPayment.setStatus(cancelledStatus);
        paymentRepository.save(refundPayment);
        return new PaymentDTO(refundPayment.getId(), refundPayment.getAmount(), 2, refundPayment.getOrders().getId(), LocalDateTime.now());
    }
}