package com.intellilearn.onlinestore.repository;

import com.intellilearn.onlinestore.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Yuqing Luo
 * @date 2024/10/22 14:36
 */
public interface ProductRepository extends JpaRepository<Product, Integer> {
}
