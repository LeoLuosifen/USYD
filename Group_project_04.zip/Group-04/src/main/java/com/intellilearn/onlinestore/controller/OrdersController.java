package com.intellilearn.onlinestore.controller;

import com.intellilearn.onlinestore.dto.OrdersDTO;
import com.intellilearn.onlinestore.model.Orders;
import com.intellilearn.onlinestore.model.Result;
import com.intellilearn.onlinestore.service.OrdersService;
import com.intellilearn.onlinestore.utils.ThreadLocalUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author Yuqing Luo
 * @date 2024/10/22 14:40
 */
@RestController
@RequestMapping("/orders")
public class OrdersController {

    @Autowired
    private OrdersService ordersService;

    @GetMapping()
    public Result listOfOrders(){
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer customerId = (Integer) map.get("id");
        List<Orders> list = ordersService.getAllOrders(customerId);
        List<OrdersDTO> ordersList = new ArrayList<>();
        for (Orders orders : list) {
            OrdersDTO ordersDTO = new OrdersDTO();
            ordersDTO.setId(orders.getId());
            ordersDTO.setProductName(orders.getProduct().getProductName());
            ordersDTO.setQuantity(orders.getQuantity());
            ordersDTO.setTotalPrice(orders.getTotalPrice());
            ordersDTO.setAddress(orders.getAddress());
            ordersDTO.setOrderStatus(orders.getOrderStatus().getId());
            ordersList.add(ordersDTO);
        }
        return Result.success(ordersList);
    }
}
