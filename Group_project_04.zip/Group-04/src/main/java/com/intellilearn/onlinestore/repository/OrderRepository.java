package com.intellilearn.onlinestore.repository;

import com.intellilearn.onlinestore.model.Orders;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OrderRepository extends JpaRepository<Orders, Integer> {

    List<Orders> findAllByCustomerId(Integer customerId);
    Orders findByCustomerIdAndProductId(Integer customerId, Integer productId);
}
