package com.intellilearn.onlinestore.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Data
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     *
     */
    @ManyToOne
    @JoinColumn(name = "order_id", nullable = false)
    private Orders orders;

    /**
     *
     */
    @OneToOne
    @JoinColumn(name = "status", nullable = false)
    private TransferStatus status;

    /**
     *
     */
    @Column(nullable = false)
    private double amount;

    /**
     *
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime paymentDate;
}
