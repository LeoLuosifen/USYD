package com.intellilearn.onlinestore.config;

import com.intellilearn.onlinestore.interceptors.LoginInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @author Yuqing Luo
 * @date 2024/10/24 13:03
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {
    @Autowired
    private LoginInterceptor loginInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        // The login interface and registration interface are not intercepted
        registry.addInterceptor(loginInterceptor).excludePathPatterns("/store/customer/login", "/store/customer/register", "/store/customer/getEmail");
    }
}
