package com.intellilearn.onlinestore.controller;

import com.intellilearn.onlinestore.model.Result;
import com.intellilearn.onlinestore.repository.CustomerRepository;
import com.intellilearn.onlinestore.model.Customer;
import com.intellilearn.onlinestore.model.KeyPassword;
import com.intellilearn.onlinestore.service.CustomerService;
import com.intellilearn.onlinestore.utils.JWTUtil;
import com.intellilearn.onlinestore.utils.JasyptUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/store/customer")
public class CustomerController {
    @Autowired
    private CustomerService customerService;
    @Autowired
    CustomerRepository customerRepository;

    @PostMapping("/register")
    public Result registerCustomer(Customer customer) {

        customerService.customerRegister(customer.getUsername(), customer.getPassword(), customer.getEmail());

        return Result.success("Customer registered successfully");
    }

    @PostMapping("/login")
    public Result loginCustomer(String username, String password) {
        JasyptUtil jasyptUtil = new JasyptUtil(KeyPassword.key);
        Customer customer = customerRepository.findByUsername(username);
        if (customer == null) {
            return Result.error("Customer not found");
        }
        if (jasyptUtil.decrypt(customer.getPassword()).equals(password)) {
            Map<String, Object> claims = new HashMap<>();
            claims.put("id", customer.getId());
            claims.put("username", customer.getUsername());
            String token = JWTUtil.genToken(claims);
            return Result.success(token);
        }
        return Result.error("Password Incorrect");
    }

    @PostMapping("/getEmail")
    public Result receivedEmail(){
        System.out.println("Received an message");
        return Result.success();
    }

}
