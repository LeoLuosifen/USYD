package com.intellilearn.onlinestore.controller;

import com.intellilearn.dto.PaymentDTO;
import com.intellilearn.dto.ProductDTO;
import com.intellilearn.onlinestore.model.Product;
import com.intellilearn.onlinestore.model.Result;
import com.intellilearn.onlinestore.service.OrdersService;
import com.intellilearn.onlinestore.service.ProductService;
import com.intellilearn.onlinestore.utils.ThreadLocalUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * @author Yuqing Luo
 * @date 2024/10/22 14:41
 */
@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private OrdersService ordersService;

    @Autowired
    private ProductService productService;

    @Qualifier("httpOutChannel")
    @Autowired
    private MessageChannel httpOutChannel;

    @Autowired
    @Qualifier("httpReplyChannel")
    private MessageChannel httpReplyChannel;

    @GetMapping()
    public Result getAllProducts(){
        List<Product> list = productService.getListOfProducts();
        return Result.success(list);
    }

    @PostMapping("/purchase")
    public Result purchaseProduct(@RequestBody ProductDTO request){
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer customerId = (Integer) map.get("id");
        boolean checkOrder = ordersService.checkOrder(customerId, request.getId());
        if (checkOrder){
            return Result.error("You have already purchased this products");
        }
        PaymentDTO paymentDTO = productService.purchaseProduct(customerId, request);
        Message<PaymentDTO> message = MessageBuilder.withPayload(paymentDTO)
                .setReplyChannel(httpReplyChannel)
                .build();
        httpOutChannel.send(message);
        System.out.println("Payment info sent: " + paymentDTO);
        return Result.success(paymentDTO);
    }

    @PostMapping("/cancelled")
    public Result cancelledProduct(@RequestParam Integer orderId){
        PaymentDTO paymentDTO = productService.cancelledOrder(orderId);
        Message<PaymentDTO> message = MessageBuilder.withPayload(paymentDTO)
                .setReplyChannel(httpReplyChannel)
                .build();
        httpOutChannel.send(message);
        System.out.println("Refund info sent: " + paymentDTO);
        return Result.success(paymentDTO);
    }

}
