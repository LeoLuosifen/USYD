package com.intellilearn.onlinestore.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Yuqing Luo
 * @date 2024/10/26 16:36
 */
@Data
@NoArgsConstructor
public class OrdersDTO {
    private Integer id;
    private Double totalPrice;
    private String productName;
    private Integer quantity;
    private Integer orderStatus;
    private String address;

    public OrdersDTO(Integer id, Double totalPrice, String productName, Integer quantity, Integer orderStatus, String address) {
        this.id = id;
        this.totalPrice = totalPrice;
        this.productName = productName;
        this.quantity = quantity;
        this.orderStatus = orderStatus;
        this.address = address;
    }
}
