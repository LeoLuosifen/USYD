package com.intellilearn.onlinestore.service;

import com.intellilearn.onlinestore.model.Warehouse;
import com.intellilearn.onlinestore.model.WarehouseStock;
import com.intellilearn.onlinestore.repository.WarehouseRepository;
import com.intellilearn.onlinestore.repository.WarehouseStockRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Yuqing Luo
 * @date 2024/10/24 17:32
 */
@Service
public class WarehouseStockService {

    @Autowired
    private WarehouseRepository warehouseRepository;

    @Autowired
    private WarehouseStockRepository warehouseStockRepository;

    public void getWarehousesToFulfillOrder(int productId, int quantity){
        List<WarehouseStock> stocks = warehouseStockRepository.findWarehouseStockById(productId);
        int remainingQuantity = quantity;

        for (WarehouseStock stock : stocks){
            Integer stockQuantity = stock.getStockQuantity();

            if (stockQuantity >= remainingQuantity){
                // Current warehouse stock is sufficient to meet remaining requirements
                stock.setStockQuantity(stockQuantity - remainingQuantity);
                warehouseStockRepository.save(stock);
                remainingQuantity = 0;
                break;
            }else {
                remainingQuantity -= stockQuantity;
                stock.setStockQuantity(0);
                warehouseStockRepository.save(stock);
            }
        }

        if (remainingQuantity > 0){
            throw new IllegalArgumentException("Not enough stock in any warehouse");
        }
    }

    public void returnProducts(Integer productId, Integer quantity){
        List<WarehouseStock> stocks = warehouseStockRepository.findWarehouseStockById(productId);
        int returnQuantity = quantity;

        for (WarehouseStock stock : stocks) {

            if (returnQuantity <= 0){
                break; // 所有库存已经恢复完毕
            }

            Integer stockQuantity = stock.getStockQuantity();
            if (stockQuantity + returnQuantity >= 50){
                returnQuantity = returnQuantity - (50 - stockQuantity);
                stock.setStockQuantity(50);
                warehouseStockRepository.save(stock);
                break;
            }else {
                stock.setStockQuantity(stockQuantity + returnQuantity);
                warehouseStockRepository.save(stock);
                returnQuantity = 0;
            }
        }

        if (returnQuantity > 0) {
            throw new RuntimeException("Not enough warehouse space to restore all inventory.");
        }
    }
}
