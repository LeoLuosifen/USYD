package com.intellilearn.onlinestore.repository;

import com.intellilearn.onlinestore.model.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<Payment, Integer> {

    Payment findByOrdersId(Integer ordersId);
}
