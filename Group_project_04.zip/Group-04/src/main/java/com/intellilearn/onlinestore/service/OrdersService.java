package com.intellilearn.onlinestore.service;

import com.intellilearn.onlinestore.model.Orders;
import com.intellilearn.onlinestore.repository.OrderRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Yuqing Luo
 * @date 2024/10/22 14:38
 */
@Service
public class OrdersService {

    @Autowired
    private OrderRepository orderRepository;

    @Transactional
    public List<Orders> getAllOrders(Integer customerId) {
        return orderRepository.findAllByCustomerId(customerId);
    }

    @Transactional
    public boolean checkOrder(Integer customerId, Integer productId){
        Orders orders = orderRepository.findByCustomerIdAndProductId(customerId, productId);
        if (orders != null){
            return true;
        }
        return false;
    }
}
