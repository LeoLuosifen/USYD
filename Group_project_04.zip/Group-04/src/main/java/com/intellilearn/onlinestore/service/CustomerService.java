package com.intellilearn.onlinestore.service;

import com.intellilearn.onlinestore.model.BankTransaction;
import com.intellilearn.onlinestore.repository.BankTransactionRepository;
import com.intellilearn.onlinestore.repository.CustomerRepository;
import com.intellilearn.onlinestore.model.Customer;
import com.intellilearn.onlinestore.model.KeyPassword;
import com.intellilearn.onlinestore.utils.JasyptUtil;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private BankTransactionRepository bankTransactionRepository;

    @Transactional
    public void customerRegister(String username, String password, String email) {
        JasyptUtil jasyptUtil = new JasyptUtil(KeyPassword.key);
        String encryptPassword = jasyptUtil.encrypt(password);
        Customer customer = new Customer();
        customer.setUsername(username);
        customer.setPassword(encryptPassword);
        customer.setEmail(email);
        customerRepository.save(customer);

        BankTransaction bankTransaction = new BankTransaction();
        bankTransaction.setCustomer(customer);
        bankTransaction.setAmount(20000.0);
        bankTransactionRepository.save(bankTransaction);
    }

}
