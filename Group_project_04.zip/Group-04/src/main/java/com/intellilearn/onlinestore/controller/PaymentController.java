package com.intellilearn.onlinestore.controller;

import org.springframework.web.bind.annotation.RestController;

/**
 * @author Yuqing Luo
 * @date 2024/10/22 14:40
 */
@RestController
public class PaymentController {
}
