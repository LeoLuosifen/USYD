package com.intellilearn.onlinestore.model;

public class KeyPassword {
    public static final String key = "mySecretKey";

}
