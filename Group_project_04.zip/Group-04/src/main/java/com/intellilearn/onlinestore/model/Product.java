package com.intellilearn.onlinestore.model;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;

@Entity
@Data
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     *
     */
    @Column(nullable = false)
    private String productName;

    /**
     *
     */
    private String productDescription;

    /**
     *
     */
    @Column(nullable = false)
    private double price;
}
