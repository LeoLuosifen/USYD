package com.intellilearn.onlinestore.service;

import org.springframework.stereotype.Service;

/**
 * @author Yuqing Luo
 * @date 2024/10/22 14:40
 */
@Service
public class WarehouseService {
}
