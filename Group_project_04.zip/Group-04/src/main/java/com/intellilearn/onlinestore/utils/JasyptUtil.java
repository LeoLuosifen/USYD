package com.intellilearn.onlinestore.utils;

import org.jasypt.util.text.BasicTextEncryptor;
import org.jasypt.util.text.StrongTextEncryptor;


public class JasyptUtil {
    private final BasicTextEncryptor textEncryptor;

    /**
     * BasicTextEncryptor
     * @param password key
     */
    public JasyptUtil(String password) {
        this.textEncryptor = new BasicTextEncryptor();
        this.textEncryptor.setPassword(password);
    }

    /**
     * encrypted string
     * @param plainText
     * @return encrypted string
     */
    public String encrypt(String plainText) {
        return textEncryptor.encrypt(plainText);
    }

    /**
     * decrypted string
     * @param encryptedText encrypted string
     * @return decrypted string
     */
    public String decrypt(String encryptedText) {
        return textEncryptor.decrypt(encryptedText);
    }

    /**
     * Using StrongTextEncryptor Enhanced encryption
     * @param plainText
     * @param password keys
     * @return encrypted string
     */
    public static String strongEncrypt(String plainText, String password) {
        StrongTextEncryptor strongEncryptor = new StrongTextEncryptor();
        strongEncryptor.setPassword(password);
        return strongEncryptor.encrypt(plainText);
    }

    /**
     * Using StrongTextEncryptor Enhanced decryption
     * @param encryptedText
     * @param password keys
     * @return decrypted string
     */
    public static String strongDecrypt(String encryptedText, String password) {
        StrongTextEncryptor strongEncryptor = new StrongTextEncryptor();
        strongEncryptor.setPassword(password);
        return strongEncryptor.decrypt(encryptedText);
    }
}
