package com.intellilearn.dto;

import com.intellilearn.onlinestore.model.OrderStatus;
import com.intellilearn.onlinestore.model.Orders;
import com.intellilearn.onlinestore.model.Payment;
import com.intellilearn.onlinestore.model.TransferStatus;
import jakarta.persistence.FetchType;
import jakarta.persistence.ManyToOne;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author Yuqing Luo
 * @date 2024/10/24 22:08
 */
@Data
public class PaymentDTO {
    private Integer id;
    private Double amount;
    private Integer transferStatus; // status id
    private Integer orderId;  // order id
    private LocalDateTime paymentDate;

    public PaymentDTO(){}

    public PaymentDTO(Integer id, Double amount, Integer transferStatus, Integer orderId, LocalDateTime paymentDate) {
        this.id = id;
        this.amount = amount;
        this.transferStatus = transferStatus;
        this.orderId = orderId;
        this.paymentDate = paymentDate;
    }
}
