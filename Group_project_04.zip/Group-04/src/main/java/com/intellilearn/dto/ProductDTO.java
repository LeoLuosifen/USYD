package com.intellilearn.dto;

import lombok.Data;

/**
 * @author Yuqing Luo
 * @date 2024/10/24 11:58
 */
@Data
public class ProductDTO {
    private Integer id;
    private String name;
    private Double price;
    private Integer quantity;
    private String address;
}
