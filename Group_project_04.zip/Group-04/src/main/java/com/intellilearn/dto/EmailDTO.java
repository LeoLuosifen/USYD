package com.intellilearn.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Yuqing Luo
 * @date 2024/10/25 14:18
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmailDTO {
    private Integer customerId;
    private Integer orderId;
    private String message;
}
