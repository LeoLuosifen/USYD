# Back-end

Before running the project, configuring the environment correctly first.

Tech stacks:

- JDK 17+
- Springboot 3.3.4
- MySQL 8.0 (recommended)
- Maven 3.6 +



And the file of properties of onlinestore, email, and delivery

```yaml
spring.application.name=onlinestore

spring.datasource.url=jdbc:mysql://localhost:3306/online-store
spring.datasource.username=root
spring.datasource.password= #your password

spring.jpa.properties.hibernate.jdbc.lob.non_contextual_creation=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQLDialect
spring.jpa.open-in-view=true

# Hibernate ddl auto (create, create-drop, validate, update)
spring.jpa.hibernate.ddl-auto= update

server.port=8081
```



Then start the three applications, which are OnlineStoreApplication, EmailProviderApplication, and DeliveryApplication.



# Front-end

Tech stacks:

- Vue3
- Element-plus



Before running, open the front-end project's directory in the terminal and execute the following command:

```shell
# download the missing packages
npm install

# start the project
npm run dev
```



Then you can assess the ` http://localhost:5173/`