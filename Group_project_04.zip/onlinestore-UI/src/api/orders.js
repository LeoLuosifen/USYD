import request from '@/utils/request.js'
import { useTokenStore } from '@/stores/token.js'
//商品分类列表查询
export const ordersListService = ()=>{
    return request.get('/orders')
}

export const cancelOrder = (id) =>{
    return request.post('/products/cancelled?orderId='+id)
}