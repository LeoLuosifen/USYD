import request from '@/utils/request.js'
import { useTokenStore } from '@/stores/token.js'
//商品分类列表查询
export const productsCategoryListService = ()=>{
    return request.get('/products')
}

//文章分类修改
export const productPurchaseService = (productData)=>{
    console.log(productData)
    return request.post('/products/purchase', productData)
}

