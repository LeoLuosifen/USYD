<script setup>
import {
    Edit,
    Delete
} from '@element-plus/icons-vue'
import { ref } from 'vue'
const products = ref([])
import { productsCategoryListService, productPurchaseService } from '@/api/products.js'

const productsCategoryList = async () => {
  let result = await productsCategoryListService();
  products.value = result.data;
}
productsCategoryList();
//控制添加分类弹窗
const dialogVisible = ref(false)

const productModel = ref({
  productName: '',
  productDescription: '',
  price: '',
  quantity: '',
  address: ''
})

//添加分类表单校验
const rules = {
    categoryName: [
        { required: true, message: '请输入分类名称', trigger: 'blur' },
    ],
    categoryAlias: [
        { required: true, message: '请输入分类别名', trigger: 'blur' },
    ]
}

//调用接口,添加表单
import { ElMessage } from 'element-plus'

//定义变量,控制标题的展示
const title = ref('')

//展示编辑弹窗
const showDialog = (row) => {
    dialogVisible.value = true; title.value = 'Product Information'
    //数据拷贝
    productModel.value.productName = row.productName;
    productModel.value.productDescription = row.productDescription;
    productModel.value.price = row.price;
    productModel.value.id = row.id
}

//编辑分类
const purchaseProduct = async () => {
    //调用接口
    let result = await productPurchaseService(productModel.value);

    ElMessage.success(result.msg ? result.msg : 'Purchase Successfully')

    await productsCategoryList();

    dialogVisible.value = false;
}

</script>
<template>
    <el-card class="page-container">
        <template #header>
            <div class="header">
                <span>List of product</span>
            </div>
        </template>
        <el-table :data="products" style="width: 100%">
            <el-table-column label="No." width="100" type="index"> </el-table-column>
            <el-table-column label="Product" prop="productName"></el-table-column>
            <el-table-column label="Description" prop="productDescription"></el-table-column>
            <el-table-column label="Price" prop="price"></el-table-column>
            <el-table-column label="Operation" width="100">
                <template #default="{ row }">
                  <div style="display: flex; justify-content: center; align-items: center;">
                    <el-button :icon="Edit" circle plain type="primary" @click="showDialog(row)"></el-button>
                  </div>
                </template>
            </el-table-column>
            <template #empty>
                <el-empty description="No data" />
            </template>
        </el-table>

        <!-- 添加分类弹窗 -->
        <el-dialog v-model="dialogVisible" :title="title" width="30%">
            <el-form :model="productModel" :rules="rules" label-width="100px" style="padding-right: 30px">
                <el-form-item label="Name" prop="productName">
                    <el-input v-model="productModel.productName" minlength="1" maxlength="10"></el-input>
                </el-form-item>
                <el-form-item label="Description" prop="productDescription">
                    <el-input v-model="productModel.productDescription" minlength="1" maxlength="15"></el-input>
                </el-form-item>
                <el-form-item label="Price" prop="price">
                  <el-input v-model="productModel.price" minlength="1" maxlength="15"></el-input>
                </el-form-item>
                <el-form-item label="Quantity" prop="quantity">
                  <el-input v-model="productModel.quantity" minlength="1" maxlength="15"></el-input>
                </el-form-item>
                <el-form-item label="Address" prop="address">
                  <el-input v-model="productModel.address" minlength="1" maxlength="15"></el-input>
                </el-form-item>
            </el-form>
            <template #footer>
                <span class="dialog-footer">
                    <el-button @click="dialogVisible = false">Cancelled</el-button>
                    <el-button type="primary" @click="purchaseProduct()"> Purchase </el-button>
                </span>
            </template>
        </el-dialog>
    </el-card>
</template>

<style lang="scss" scoped>
.page-container {
    min-height: 100%;
    box-sizing: border-box;

    .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
}
</style>