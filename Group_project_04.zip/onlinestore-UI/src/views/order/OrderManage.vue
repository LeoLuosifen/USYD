<script setup>
import {
    Delete
} from '@element-plus/icons-vue'

import { ref } from 'vue'

const orders = ref([])

import { ordersListService, cancelOrder } from '@/api/orders.js'

const orderList = async () => {
  let result = await ordersListService();
  orders.value = result.data
}

orderList()

import '@vueup/vue-quill/dist/vue-quill.snow.css'

//添加文章
import {ElMessage, ElMessageBox} from 'element-plus'
const deleteCategory = (row) => {
  //提示用户  确认框

  ElMessageBox.confirm(
      'Are you sure you want to cancel this order?',
      'Please note.',
      {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Cancel',
        type: 'warning',
      }
  )
      .then(async () => {
        console.log(row.id)
        let result = await cancelOrder(row.id);
        ElMessage({
          type: 'success',
          message: 'Order Cancellation Success',
        })
        //刷新列表
        await orderList()
      })
      .catch(() => {
        ElMessage({
          type: 'info',
          message: 'User cancelled the operation',
        })
      })
}
</script>
<template>
    <el-card class="page-container">
        <template #header>
            <div class="header">
                <span>Orders</span>
            </div>
        </template>
        <!-- 文章列表 -->
        <el-table :data="orders" style="width: 100%">
            <el-table-column label="No." width="100" type="index"> </el-table-column>
            <el-table-column label="Product" prop="productName"></el-table-column>
            <el-table-column label="Price" prop="totalPrice"></el-table-column>
            <el-table-column label="Quantity" prop="quantity"></el-table-column>
            <el-table-column label="Status" prop="orderStatus"></el-table-column>
            <el-table-column label="Address" prop="address"></el-table-column>
            <el-table-column label="Operation" width="100">
                <template #default="{ row }">
                  <div style="display: flex; justify-content: center; align-items: center;">
                    <el-button :icon="Delete" circle plain type="danger" @click="deleteCategory(row)"></el-button>
                  </div>
                </template>
            </el-table-column>
            <template #empty>
                <el-empty description="No data" />
            </template>
        </el-table>

    </el-card>
</template>
<style lang="scss" scoped>
.page-container {
    min-height: 100%;
    box-sizing: border-box;

    .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
}

/* 抽屉样式 */
.avatar-uploader {
    :deep() {
        .avatar {
            width: 178px;
            height: 178px;
            display: block;
        }

        .el-upload {
            border: 1px dashed var(--el-border-color);
            border-radius: 6px;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            transition: var(--el-transition-duration-fast);
        }

        .el-upload:hover {
            border-color: var(--el-color-primary);
        }

        .el-icon.avatar-uploader-icon {
            font-size: 28px;
            color: #8c939d;
            width: 178px;
            height: 178px;
            text-align: center;
        }
    }
}

.editor {
    width: 100%;

    :deep(.ql-editor) {
        min-height: 200px;
    }
}
</style>